
Name : Adnane

Lastname : Adnane

Course : SEG 3503  

Content : Lab 1 & 3 

Hi, My name is Adnane and I'm pushing this as instructed in lab 3. 
In this lab I implemented funtions to test as mentioned in lab 3. 
Thank you for your time and correction :) 